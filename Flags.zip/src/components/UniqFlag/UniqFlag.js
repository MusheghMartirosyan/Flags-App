import { useNavigate } from "react-router-dom"
import { useParams } from "react-router-dom"
// import './UniqFlag.css'
import './UniqFlag.css'

const UniqFlag = ({flags}) => {

    const id = useParams()
    const navigate = useNavigate()

    return(
        <>
            <div className='uniqFlag'>
                <h1 className="uniqH1">{flags.filter(flags => flags.id === id).title}</h1>
                <img className="uniqImg" src={flags.filter(flags => flags.id === id).img} alt=""/>
                <p className="uniqP">{flags.filter(flags => flags.id === id).aboutAll}</p>
                <button className='uniqBackBtn' onClick={() => navigate(-1)}>Back</button>
            </div>
        </>
    )
}
export default UniqFlag