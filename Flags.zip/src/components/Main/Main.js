import './Main.css'

const Main = () => {
    
    
    return(
        <>
        <div className='main'>
            <h2>Welcome to the flags application</h2>
            <p>Here you will find the flags you are interested in and information about them</p>
        </div>
        </>
    )
}
export default Main